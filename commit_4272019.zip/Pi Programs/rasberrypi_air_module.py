#Import necessary libraries
#RPi.GPIO necessary to use GPIO pins on RPi
import RPi.GPIO as GPIO
#Time library for delays
import time
#Necessary to handle I2C communication
import smbus

#Pin definitions
ledPin = 17
sdaPin = 2
sclPin = 3
piezoPin = 12

"""
Set RPi GPIO mode - in this case, we are referring to the RPi's GPIO pins
according to the numbering printed on the motherboard. This is because the
datalogger doesn't use a Pi Wedge or similar device, so it's just easier
this way.
"""
GPIO.setmode(GPIO.BOARD)

print("GPIO mode set to BOARD")
